from pessoa3 import Pessoa
p1 = Pessoa('Joao ', 32)
print(p1)
print(p1.nome, p1.idade)
p1.get_ano_nascimento()
p2 = Pessoa.por_ano_nascimento('Pedro', 1983)
print(p2)
print(p2.nome, p2.idade)
p2.get_ano_nascimento()
print(Pessoa.gera_id())
print(p1.gera_id())

