from pessoa1 import Pessoa
p1 = Pessoa('Joao ', 32)
p1.parar_comer()
p1.comer('Hamburger')
p1.falar()


