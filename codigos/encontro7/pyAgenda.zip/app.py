import os
from flask import Flask
from routes import main as main_routes
from db import db  # Import db from the new db.py
from models import Contact  # Import your model here

app = Flask(__name__)
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///database.db'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
db.init_app(app)  # Initialize the app with the db

# Verifica se o banco de dados existe e cria a tabela se necessário
def create_db():
    if not os.path.exists('database.db'):
        with app.app_context():
            db.create_all()  # Create the tables

create_db() # Chama a função para verificar e criar o banco de dados
app.register_blueprint(main_routes)

if __name__ == '__main__':
    app.run(debug=True)
